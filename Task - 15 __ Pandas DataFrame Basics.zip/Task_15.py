import pandas as pd

# Create a DataFrame manually
student_df = pd.DataFrame({
    "Name": ["Aman", "Priya", "Rahul", "Neha"],
    "Age": [20, 21, 20, 22],
    "Marks": [82, 91, 76, 88]
})
print("MANUAL DATAFRAME")
print(student_df)

# Load a dataset
df = pd.read_csv("student_performance.csv")

print("\nFIRST FIVE ROWS")
print(df.head())

print("\nLAST FIVE ROWS")
print(df.tail())

print("\nSHAPE:", df.shape)
print("ROWS:", df.shape[0])
print("COLUMNS:", df.shape[1])

print("\nCOLUMN NAMES")
print(df.columns.tolist())

print("\nDATA TYPES")
print(df.dtypes)

print("\nDATA INFORMATION")
df.info()

print("\nSUMMARY STATISTICS")
print(df.describe())

print("\nAVERAGE PYTHON MARKS:", round(df["Python_Marks"].mean(), 2))
print("HIGHEST SQL MARKS:", df["SQL_Marks"].max())
print("LOWEST ATTENDANCE:", df["Attendance"].min())

print("\nSTUDENTS WITH AVERAGE >= 80")
print(df[df["Average"] >= 80][["Name", "Average", "Performance"]])

print("\nMISSING VALUES")
print(df.isnull().sum())
